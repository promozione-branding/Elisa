# Product Images Folder

Place product images here matching the filenames referenced in `products-data.js`.

Suggested image naming (already used in data.js):

- esomeprazole-40mg.jpg
- pantoprazole-injection.jpg
- pantoprazole-tablet.jpg
- pantoprazole-domperidone.jpg
- magnesium-hydroxide.jpg
- omeprazole-20mg.jpg
- sucralfate-oxetacaine.jpg
- esmo-ls.jpg
- esmo-dsr.jpg
- rabeprazole-domperidone.jpg
- albendazole-suspension.jpg
- lactulose.jpg
- nugesia-3.jpg
- nugesia-ac.jpg
- actagesic-mr.jpg
- benz-ls.jpg
- etoricoxib-90.jpg
- etoxizip-mr.jpg
- nimesulide-paracetamol.jpg
- nugesia-sp.jpg
- paracetamol-650.jpg
- nugesia-tra.jpg
- azithromycin-500.jpg
- azithromycin-250.jpg
- doxycycline-100.jpg
- cefuroxime-500.jpg
- linezolid-600.jpg
- amoxycillin-500.jpg
- pureclav-ds.jpg
- ciprofloxacin-500.jpg
- ceftriaxone-sulbactam.jpg
- cefixime-ofloxacin.jpg
- cefixime-dt-200.jpg
- levofloxacin-500.jpg
- ofloxacin-200.jpg
- puredox-cv.jpg
- myo-inositol.jpg
- methylcobalamin-ala.jpg
- lycopene-syrup.jpg
- multivitamin-syrup.jpg
- omega3-capsule.jpg
- coq10-lycopene.jpg
- calcitriol-calcium.jpg
- bcomplex-lysine.jpg
- iron-folic-zinc.jpg
- staircal-500.jpg
- ketozip-ointment.jpg
- fexozip-180.jpg
- neuroarv-nt.jpg
- pureclav-injection.jpg

You can download product images from the IndiaMART product pages:
https://www.indiamart.com/elisabiotech/
or https://export.indiamart.com/company/elisabiotech/

Recommended size: 400x400 or 500x500 px, JPG/WebP format.
